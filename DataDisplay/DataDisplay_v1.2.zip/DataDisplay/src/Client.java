public class Client {
    private String client_id;
    private String client_type;
    private String description;
    private String longitude;
    private String latitude;
    private String location;


    public Client(String client_id, String client_type, String description, String longitude, String latitude, String location) {
        this.client_id = client_id;
        this.client_type = client_type;
        this.description = description;
        this.longitude = longitude;
        this.latitude = latitude;
        this.location = location;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    public String getClient_type() {
        return client_type;
    }

    public void setClient_type(String client_type) {
        this.client_type = client_type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
