// get the average temperature and humidity for the past 7X24 hours

import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetHourTHServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetHourTHServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,temperature,humidity from hour_data where client_id=" + id + " order by id desc limit 168";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> tArray = new ArrayList<String>();
        ArrayList<String> hArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                tArray.add(rs.getString("temperature"));
                hArray.add(rs.getString("humidity"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd HH:00");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] tData = new float[tArray.size()];
        float[] hData = new float[tArray.size()];
        String[] timeData = new String[tArray.size()];

        for (int i = 0; i < tArray.size(); i++) {
            tData[i] = Float.parseFloat(tArray.get(tArray.size() - i - 1));
            hData[i] = Float.parseFloat(hArray.get(hArray.size() - i - 1));
            timeData[i] = timeArray.get(hArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("tData", tData);
        map.put("hData", hData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}