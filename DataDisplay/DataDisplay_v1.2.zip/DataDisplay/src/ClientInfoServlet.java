import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClientInfoServlet extends HttpServlet {
    public ClientInfoServlet() {
        super();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        List<Map> list = new ArrayList<Map>();

        HttpSession session = request.getSession();
        DB db = new DB();
        String sql = "select * from client_info;";
        try {
            ResultSet rs = db.query(sql);
            while (rs.next()) {
                Map<String, String> map = new HashMap<>();
                map.put("longitude", rs.getString("longitude"));
                map.put("latitude", rs.getString("latitude"));
                map.put("location", rs.getString("location"));
                list.add(map);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        db.close();
        session.setAttribute("clientList", list);
        response.sendRedirect("index.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
