// get the average CO for the past 7X24 hours

import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetHourCOServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetHourCOServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,co from hour_data where client_id=" + id + " order by id desc limit 168";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> coArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                coArray.add(rs.getString("co"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd HH:00");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] coData = new float[coArray.size()];
        String[] timeData = new String[coArray.size()];

        for (int i = 0; i < coArray.size(); i++) {
            coData[i] = Float.parseFloat(coArray.get(coArray.size() - i - 1));
            timeData[i] = timeArray.get(coArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("coData", coData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}