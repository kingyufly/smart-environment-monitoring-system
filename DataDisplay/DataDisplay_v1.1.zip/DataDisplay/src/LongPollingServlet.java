import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LongPollingServlet extends HttpServlet {
    public LongPollingServlet() {
        super();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        PrintWriter writer = response.getWriter();
        String sql = "select * from raw_data order by id desc limit 1;";
        Weather weather;
        String weatherStrOld;
        DB db = new DB();
        ResultSet rs;
        try {
            rs = db.query(sql);
            rs.next();
            String time = rs.getString("timestamp");
            String[] timeStr = time.split("\\.");
            weather = new Weather(rs.getString("temperature"), rs.getString("humidity"), rs.getString("pm2_5"), rs.getString("co"), timeStr[0]);
            weatherStrOld = weather.toString();

            while (true) {
                rs = db.query(sql);
                rs.next();
                time = rs.getString("timestamp");
                timeStr = time.split("\\.");
                weather = new Weather(rs.getString("temperature"), rs.getString("humidity"), rs.getString("pm2_5"), rs.getString("co"), timeStr[0]);
                String weatherStrNew = weather.toString();
                if (!weatherStrNew.equals(weatherStrOld)) {
                    writer.print(new JSONObject(weather));
                    break;
                } else {
                    weatherStrOld = weatherStrNew;
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        writer.close();
        db.close();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
