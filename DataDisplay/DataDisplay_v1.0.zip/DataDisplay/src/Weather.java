public class Weather implements Cloneable {
    private String temperature;
    private String humidity;
    private String pm2_5;
    private String co;
    private String time;

    public Weather() {
    }

    public Weather(String temperature, String humidity, String pm2_5, String co, String time) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.pm2_5 = pm2_5;
        this.co = co;
        this.time = time;
    }

    public void increase() {
        this.temperature = this.temperature + 1;
        this.humidity = this.humidity + 1;
        this.pm2_5 = this.pm2_5 + 1;
        this.co = this.co + 1;
    }

    @Override
    public Object clone() {
        Weather w = null;
        try {
            w = (Weather) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return w;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getPm2_5() {
        return pm2_5;
    }

    public void setPm2_5(String pm2_5) {
        this.pm2_5 = pm2_5;
    }

    public String getCo() {
        return co;
    }

    public void setCo(String co) {
        this.co = co;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String toString() {
        return this.temperature + ";" + this.humidity + ";" + this.pm2_5 + ";" + this.co + ";" + this.time;
    }
}
