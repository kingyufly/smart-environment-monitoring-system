//get the max pm2.5 for the past 30 days

import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetDayPMServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetDayPMServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,pm2_5_max from day_data where client_id=" + id + " order by id desc limit 60";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> pmMaxArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                pmMaxArray.add(rs.getString("pm2_5_max"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] pmMaxData = new float[pmMaxArray.size()];
        String[] timeData = new String[pmMaxArray.size()];

        for (int i = 0; i < pmMaxArray.size(); i++) {
            pmMaxData[i] = Float.parseFloat(pmMaxArray.get(pmMaxArray.size() - i - 1));
            timeData[i] = timeArray.get(pmMaxArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("pmMaxData", pmMaxData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}