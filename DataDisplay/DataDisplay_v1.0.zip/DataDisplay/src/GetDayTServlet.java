//get the max and min temperature for the last 30 days

import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetDayTServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetDayTServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,temperature_max,temperature_min from day_data where client_id=" + id + " order by id desc limit 60";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> tMaxArray = new ArrayList<String>();
        ArrayList<String> tMinArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                tMaxArray.add(rs.getString("temperature_max"));
                tMinArray.add(rs.getString("temperature_min"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] tMaxData = new float[tMaxArray.size()];
        float[] tMinData = new float[tMaxArray.size()];
        String[] timeData = new String[tMaxArray.size()];

        for (int i = 0; i < tMaxArray.size(); i++) {
            tMaxData[i] = Float.parseFloat(tMaxArray.get(tMaxArray.size() - i - 1));
            tMinData[i] = Float.parseFloat(tMinArray.get(tMaxArray.size() - i - 1));
            timeData[i] = timeArray.get(tMaxArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("tMaxData", tMaxData);
        map.put("tMinData", tMinData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}