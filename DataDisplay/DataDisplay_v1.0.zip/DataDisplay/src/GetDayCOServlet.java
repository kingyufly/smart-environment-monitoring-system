//get the max co for the past 30 days

import org.json.JSONObject;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetDayCOServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetDayCOServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,co_max from day_data where client_id=" + id + " order by id desc limit 60";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> coMaxArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                coMaxArray.add(rs.getString("co_max"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] coMaxData = new float[coMaxArray.size()];
        String[] timeData = new String[coMaxArray.size()];

        for (int i = 0; i < coMaxArray.size(); i++) {
            coMaxData[i] = Float.parseFloat(coMaxArray.get(coMaxArray.size() - i - 1));
            timeData[i] = timeArray.get(coMaxArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("coMaxData", coMaxData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doGet(request, response);
    }
}