//get the max and min humidity for the last 30 days

import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class GetDayHServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public GetDayHServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        String id = (String) session.getAttribute("id");

        String sql = "select timestamp,humidity_max,humidity_min from day_data where client_id=" + id + " order by id desc limit 60";
        DB db = new DB();
        ResultSet rs;

        ArrayList<String> hMaxArray = new ArrayList<String>();
        ArrayList<String> hMinArray = new ArrayList<String>();
        ArrayList<String> timeArray = new ArrayList<String>();

        try {
            rs = db.query(sql);
            while (rs.next()) {
                hMaxArray.add(rs.getString("humidity_max"));
                hMinArray.add(rs.getString("humidity_min"));
                String time = rs.getString("timestamp");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = sdf.parse(time);
                sdf = new SimpleDateFormat("MM-dd");
                timeArray.add(sdf.format(date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }

        db.close();
        float[] hMaxData = new float[hMaxArray.size()];
        float[] hMinData = new float[hMaxArray.size()];
        String[] timeData = new String[hMaxArray.size()];

        for (int i = 0; i < hMaxArray.size(); i++) {
            hMaxData[i] = Float.parseFloat(hMaxArray.get(hMaxArray.size() - i - 1));
            hMinData[i] = Float.parseFloat(hMinArray.get(hMaxArray.size() - i - 1));
            timeData[i] = timeArray.get(hMaxArray.size() - i - 1);
//            System.out.println(tData[i] + ";" + hData[i] + ";" + timeData[i]);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("hMaxData", hMaxData);
        map.put("hMinData", hMinData);
        map.put("timeData", timeData);

        JSONObject a = new JSONObject(map);
        response.getWriter().println(a.toString());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}