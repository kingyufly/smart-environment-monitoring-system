import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DetialServlet extends HttpServlet {
    public DetialServlet() {
        super();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String id = request.getParameter("id");
        HttpSession session = request.getSession();
        session.setAttribute("id", id);

        DB db = new DB();
        String sql = "select * from client_info where client_id=" + id + ";";
        try {
            ResultSet rs = db.query(sql);
            rs.next();

            session.setAttribute("client_id", rs.getString("client_id"));
            session.setAttribute("device_type", rs.getString("device_type"));
            session.setAttribute("description", rs.getString("description"));
            session.setAttribute("longitude", rs.getString("longitude"));
            session.setAttribute("latitude", rs.getString("latitude"));
            session.setAttribute("location", rs.getString("location"));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        db.close();

        response.sendRedirect("InfoDisplay.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
