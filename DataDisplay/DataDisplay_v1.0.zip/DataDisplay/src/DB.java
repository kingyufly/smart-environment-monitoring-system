import java.sql.*;

public class DB {
    private static final String url = "jdbc:mysql://123.56.8.117/environment?useSSL=false";
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "outeruser";
    private static final String password = "Abcd1234!";

    private Connection conn = null;

    public DB() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            this.conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet query(String sql) throws SQLException {
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
    }
}
