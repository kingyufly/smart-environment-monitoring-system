import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import java.io.IOException;

public class ClientSubscribe {

	public static final String HOST = "tcp://127.0.0.1:1883";
	private static final String clientid = "server";
	public static final String TOPICS1 = "1";  
	public static final String TOPICS2 = "2"; 
	public static final String TOPICS3 = "3"; 
	private MqttClient client;
	private MqttConnectOptions options;

	private void start() {
		try {
			client = new MqttClient(HOST, clientid);
			options = new MqttConnectOptions();
			options.setCleanSession(false);
			options.setConnectionTimeout(10);
			options.setKeepAliveInterval(20);
			client.setCallback(new PushCallback());
			client.connect(options);

			int[] Qos = { 1 };
			String[] topics1 = {TOPICS1}; // Topics that will be subscribed by the client
			String[] topics2 = {TOPICS2}; // Topics that will be subscribed by the client
			String[] topics3 = {TOPICS3}; // Topics that will be subscribed by the client
			client.subscribe(topics1, Qos);
			client.subscribe(topics2, Qos);
			client.subscribe(topics3, Qos);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void startProcess(String command) {
		try {
			Runtime.getRuntime().exec(command);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// Delay 30s for the system and network to initialize
		//try {
		//	Thread.sleep(30000);
		//} catch (InterruptedException e) {
		//	// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}

		//startProcess("mosquitto -v");
		// Delay 2s for MQTT broker to initialize
		//try {
		//	Thread.sleep(2000);
		//} catch (InterruptedException e) {
		//	// TODO Auto-generated catch block
		//	e.printStackTrace();
		//}
		// Start to subscribe and uploading data
		ClientSubscribe client = new ClientSubscribe();
		client.start();
	}
}
