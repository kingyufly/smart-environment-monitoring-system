import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONObject;

public class PushCallback implements MqttCallback {
	DB mysqlDB = new DB();

	@Override
	public void connectionLost(Throwable cause) {
		System.out.println("connection lost!");
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		System.out.println("deliveryComplete---------" + token.isComplete());
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		System.out.println("Topic: " + topic);
		System.out.println("Qos: " + message.getQos());
		System.out.println("Message: " + new String(message.getPayload()));
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		System.out.println(sdf.format(new Date()));
		System.out.println();

		/*JSONObject dataJSON = new JSONObject(new String(message.getPayload()));
		if (!topic.equals(dataJSON.get("client_id")))
			return;
		else {
			String SQLStatement = null;
			String SQLInsert = "insert into raw_data";
			String SQLColumn = "(timestamp,milliseconds";
			String SQLValue = ") values(";
			String SQLEnd = ");";

			Calendar now = Calendar.getInstance();
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String timestamp = sdf.format(date);
			int milliseconds = now.get(Calendar.MILLISECOND);

			SQLValue += "\"" + timestamp + "\"," + milliseconds;

			Iterator<String> dataKeys = dataJSON.keys();
			while (dataKeys.hasNext()) {
				String key = dataKeys.next();
				SQLColumn += "," + key;
				SQLValue += "," + dataJSON.getString(key);
			}
			SQLStatement = SQLInsert + SQLColumn + SQLValue + SQLEnd;
			mysqlDB.insert(SQLStatement);
		}*/
	}
}