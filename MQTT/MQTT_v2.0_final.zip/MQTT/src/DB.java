import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DB {
	public static final String url = "jdbc:mysql://123.56.8.117/environment?useSSL=false";
	public static final String driver = "com.mysql.jdbc.Driver";
	public static final String user = "outeruser";
	public static final String password = "Abcd1234!";

	public Connection conn = null;

	public DB() {
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			this.conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insert(String SQL) throws SQLException {
		Statement stmt = conn.createStatement();
		stmt.execute(SQL);
	}
}
