-- Config D0, D1, D2 as the control pin of the CD4051
gpio.mode(2, gpio.OUTPUT)
gpio.mode(1, gpio.OUTPUT)
gpio.mode(0, gpio.OUTPUT)

-- Define D5 as the data pin of DHT
dht_pin = 5

-- start configure and connect MQTT
client_id = "1"
m = mqtt.Client(client_id, 120) -- The clientID should be modified according to the location of the NodeMCU
m:connect("MQTT Broker IP", 1883, 0, function(client) print("connected") end, function(client, reason) print("failed reason: "..reason) end)

-- Delay for 1,000,000 microseconds for MQTT client to connect to the server
--tmr.delay(1500000)

-- Set the timer to run the function per seconds
tmr.alarm(1, 1000, tmr.ALARM_AUTO, function()
    data_json = {}
    data_json.client_id = client_id
	data_json.temperature = 0
	data_json.humidity = 0
	data_json.pm2_5 = 0
	data_json.co = 0
	
	--GP2Y1010AU0F(PM2.5) 000
	--MQ-7(CO) 001
	
	-- Read the value of GP2Y1010AU0F
	gpio.write(2, gpio.LOW)
	gpio.write(1, gpio.LOW)
	gpio.write(0, gpio.LOW)
	data_json.pm2_5 = -0.006764 * (adc.read(0)/1024*3.3)^2 + 0.1915*(adc.read(0)/1024*3.3) - 0.1108
    if data_json.pm2_5 < 0 then
        data_json.pm2_5 = "0.0000"
    else
        data_json.pm2_5 = string.format("%.4f", data_json.pm2_5)
    end
    
    -- Delay for 100ms for the CD405X to change the channel
	tmr.delay(100000)
	-- Read the value of MQ-7
	gpio.write(2, gpio.LOW)
	gpio.write(1, gpio.LOW)
	gpio.write(0, gpio.LOW)
	data_json.co = string.format("%d", math.ceil(300*adc.read(0)/1024*3.3 + 10))
    
    -- Read the value of DHT11
	status, temp, humi, temp_dec, humi_dec = dht.read(dht_pin)
	if status == dht.OK then
        data_json.temperature = string.format("%.2f", (temp + temp_dec))
        data_json.humidity = string.format("%.2f", (humi + humi_dec))
    elseif status == dht.ERROR_CHECKSUM then
        data_json.temperature = "99.99"
        data_json.humidity = "99.99"
    elseif status == dht.ERROR_TIMEOUT then
        data_json.temperature = "99.99"
        data_json.humidity = "99.99"
    end

    print(sjson.encode(data_json))
    m:publish("1",sjson.encode(data_json),0,0, function(client) print("sent") end)
end)
