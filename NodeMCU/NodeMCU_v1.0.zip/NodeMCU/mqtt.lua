m = mqtt.Client("NodeMCU01", 120, "user", "password")
m:lwt("/lwt", "offline", 0, 0)
m:on("connect", function(client) print ("connected") end)
m:on("offline", function(client) print ("offline") end)
m:connect("10.205.5.67", 1883, 0, function(client) print("connected") end, 
                                     function(client, reason) print("failed reason: "..reason) end)
tmr.delay(1500000)
tmr.alarm(1, 1000, 1, function()
	m:publish("test",(adc.read(0)),0,0, function(client) print("sent") end)
end)
	
	
