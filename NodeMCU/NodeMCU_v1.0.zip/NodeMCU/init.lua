if true then
	wifi.setmode(wifi.STATIONAP)
	wifi.sta.config("627","daowangzz")
	wifi.sta.connect()
	
	cnt = 0
	tmr.alarm(1, 1000, 1, function()
		if (wifi.sta.getip() == nil) and (cnt < 20) then
			print("IP unavaiable, Waiting...")
			cnt = cnt + 1
		else
			tmr.stop(1)
			if (cnt < 20) then
				print("Config done, IP is "..wifi.sta.getip())
				--dofile("http_srv.lua")
				dofile("mqtt.lua")
			else
				print("Wifi setup time more than 20s, Please verify wifi.sta.config() function. Then re-download the file.")
			end
		end
	end)
end